package com.GroupG.beans;

public class Accounts {

	private int accountno;
	private String secondaccountno;
	private String accounttype;
	private String username;
	private float accountbalance;
	private String withdrawmoney;
	private String addmoney;
	private String ammount;
	private String billingcompany;

	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public float getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(float accountbalance) {
		this.accountbalance = accountbalance;
	}
	public String getWithdrawmoney() {
		return withdrawmoney;
	}
	public void setWithdrawmoney(String withdrawmoney) {
		this.withdrawmoney = withdrawmoney;
	}
	public String getAddmoney() {
		return addmoney;
	}
	public void setAddmoney(String addmoney) {
		this.addmoney = addmoney;
	}
	public String getAmmount() {
		return ammount;
	}
	public void setAmmount(String ammount) {
		this.ammount = ammount;
	}
	public String getBillingcompany() {
		return billingcompany;
	}
	public void setBillingcompany(String billingcompany) {
		this.billingcompany = billingcompany;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public String getSecondaccountno() {
		return secondaccountno;
	}
	public void setSecondaccountno(String secondaccountno) {
		this.secondaccountno = secondaccountno;
	}
	
		
}
